
public class Gen1 {

	public static void main(String[] args) {

		//Read two input strings
		String string_1 = new String("ABAC");
		String string_2 = new String("BABD");
		StringBuffer output_string_1 = new StringBuffer();
		StringBuffer output_string_2 = new StringBuffer();

		//Find and print difference string_1 - string_2
		for(int i=0; i< string_1.length(); i++) {
			if(string_2.indexOf(string_1.charAt(i)) < 0) 
				output_string_1.append(string_1.charAt(i));
		}
			//Find and print difference string_2 - string_1
			for(int j=0; j< string_2.length(); j++) {
				if(string_1.indexOf(string_2.charAt(j)) < 0) 
					output_string_2.append(string_2.charAt(j));
			}
		
		
		System.out.println("Output String 1: " + output_string_1);
		System.out.println("Output String 2: " + output_string_2);
	}
}
