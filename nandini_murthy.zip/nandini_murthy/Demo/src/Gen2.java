import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Gen2 {
	
	public static void main(String[] args) {
		//Read user pairs strings
		String userPairs = "User1,User2,User3,User4,User1,User5,User2,User1,User3,"
				+ "User4,User4,User3";
		String[] pairs = userPairs.split(",");
		
		//Store user pairs strings in map
		Map<String, String> userMap = new HashMap<String, String>();
		for(int i=0; i<pairs.length - 1; i=i+2) {
			if(userMap.size() == 0)
				userMap.put(pairs[i], pairs[i+1]);
			else if((userMap.containsKey(pairs[i]) && userMap.containsValue(pairs[i+1]))
					|| userMap.containsValue(pairs[i]) && userMap.containsKey(pairs[i+1]))
				continue;
			else
				userMap.put(pairs[i], pairs[i+1]);
		}
		
		//Print values in map
		for(Entry<String, String> user : userMap.entrySet()) {
			System.out.println(user.getKey() + "," + user.getValue());
		}
	}
}
