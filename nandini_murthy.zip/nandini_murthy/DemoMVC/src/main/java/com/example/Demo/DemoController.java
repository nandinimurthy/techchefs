package com.example.Demo;

import java.util.List;
import java.util.Map;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.Demo.Model.Account;
import com.example.Demo.Model.Bank;
import com.example.Demo.Model.User;
import com.example.Demo.Service.DemoService;

@Controller
public class DemoController {
	
	DemoService serviceDAO = new DemoService();
	public static final String STATUS = "STATUS";
	public static final String CODE = "CODE";
	public static final String RESULT = "RESULT";
	
	@RequestMapping(value = "/api/register", method = RequestMethod.POST,
			 consumes = MediaType.APPLICATION_JSON_VALUE,
			 produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody DemoJSON register(@RequestBody User user) {
		DemoJSON json = new DemoJSON();
		Map<String, String> returnVal = serviceDAO.register(user);
		json.setStatus(returnVal.get(STATUS));
		json.setCode(returnVal.get(CODE));
		
		return json;
	}
	
	@RequestMapping(value = "/api/login", method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody DemoJSON login(@RequestBody User user) {
		DemoJSON json = new DemoJSON();
		Map<String, String> returnVal = serviceDAO.login(user);
		json.setStatus(returnVal.get(STATUS));
		json.setCode(returnVal.get(CODE));
		json.setResult(returnVal.get(RESULT));
		
		return json;
	}
	
	@RequestMapping(value = "/api/getbanklist", method = RequestMethod.GET,
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody DemoJSON getBankList() {
		DemoJSON json = new DemoJSON();
		List<Bank> returnVal = serviceDAO.getBankList();
		json.setStatus("OK");
		json.setCode("200");
		json.setResult(returnVal);
		
		return json;
	}
	
	@RequestMapping(value = "/api/getbankdata/{bankname}", method = RequestMethod.GET,
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody DemoJSON getBankData(@PathVariable String bankname) {
		DemoJSON json = new DemoJSON();
		Bank returnVal = serviceDAO.getBankData(bankname);
		json.setStatus("OK");
		json.setCode("200");
		json.setResult(returnVal);
		
		return json;
	}
	
	@RequestMapping(value = "/api/logintobank", method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody DemoJSON loginToBank(@PathVariable String bankname) {
		DemoJSON json = new DemoJSON();
		Map<String, String> returnVal = serviceDAO.loginToBank(bankname);
		json.setStatus(returnVal.get(STATUS));
		json.setCode(returnVal.get(CODE));
		json.setResult(returnVal);
		
		return json;
	}
	
	@RequestMapping(value = "/api/getaccounts/{bankname}", method = RequestMethod.GET,
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody DemoJSON getAccounts(@PathVariable String bankname) {
		DemoJSON json = new DemoJSON();
		json.setStatus("OK");
		json.setCode("200");
		Account returnVal = serviceDAO.getAccounts(bankname);
		json.setResult(returnVal);
		
		return json;
	}
	
	@RequestMapping(value = "/api/gettransactiondata", method = RequestMethod.GET,
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody DemoJSON getTransactionData(@PathVariable String accountnumber) {
		DemoJSON json = new DemoJSON();
		List<Account> returnVal = serviceDAO.getTransactionData(accountnumber);
		json.setResult(returnVal);
		
		return json;
	}
}
