package com.example.Demo.Model;

public class Bank {
	private String bankname;
	private String corpid;
	
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}
	
	public String getBankname() {
		return bankname;
	}
	
	public void setCorpid(String corpid) {
		this.corpid = corpid;
	}
	
	public String getCorpid() {
		return corpid;
	}
}
