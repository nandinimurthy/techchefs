package com.example.Demo.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.Demo.Model.Account;
import com.example.Demo.Model.Bank;
import com.example.Demo.Model.User;

public class DemoService {
	
	private static Map<String, String> userMap = new HashMap<>();
	
	public Map<String, String> register(User user){
		userMap.put(user.getUsername(), user.getPassword());
		
		Map<String, String> returnVal = new HashMap<>();
		returnVal.put("STATUS", "OK");
		returnVal.put("CODE", "200");
		
		return returnVal;
	}

	public Map<String, String> login(User user){
		if(userMap.containsKey(user.getUsername())) {
			Map<String, String> returnVal = new HashMap<>();
			returnVal.put("STATUS", "OK");
			returnVal.put("CODE", "200");
			returnVal.put("RESULT", "User Logged in");
			return returnVal;
		}
		else {
			Map<String, String> returnVal = new HashMap<>();
			returnVal.put("STATUS", "ERROR");
			returnVal.put("CODE", "401");
			returnVal.put("RESULT", "User Not Authorized");
			return returnVal;
		}
	}
	
	public List<Bank> getBankList(){
		List<Bank> bankList = new ArrayList<>();
		
		Bank bank1 = new Bank();
		bank1.setBankname("CITIBANK");
		bankList.add(bank1);
		
		Bank bank2 = new Bank();
		bank2.setBankname("STATE BANK OF INDIA");
		bankList.add(bank2);
		
		Bank bank3 = new Bank();
		bank3.setBankname("HDFC");
		bankList.add(bank3);
		
		return bankList;
	}
	
	public Bank getBankData(String bankname){
		Bank bank1 = new Bank();
		switch (bankname) {
		case "CITIBANK":
			bank1.setBankname("CITIBANK");
			bank1.setCorpid("CITI00004");
			break;
			
		case "STATE BANK OF INDIA":
			bank1 = new Bank();
			bank1.setBankname("STATE BANK OF INDIA");
			bank1.setCorpid("SBI00006");
			break;
			
		case "HDFC":
			bank1 = new Bank();
			bank1.setBankname("HDFC");
			bank1.setCorpid("HDFC00005");
			break;
		}
		return bank1;
	}
	
	public Map<String, String> loginToBank(String bankname){
		return null;
	}
	
	public Account getAccounts(String bankname){
		Account account = new Account();
		switch (bankname) {
		case "CITIBANK":
			account.setAccountnumber("123456");
			account.setType("Savings");
			break;
			
		case "STATE BANK OF INDIA":
			account.setAccountnumber("56789");
			account.setType("Deposit");
			break;
			
		case "HDFC":
			account.setAccountnumber("456712");
			account.setType("Savings");
			break;
		}
		return account;
	}
	
	public List<Account> getTransactionData(String accountnumber){
		return null;
	}
}
