package com.example.Demo.Model;

import java.util.ArrayList;
import java.util.List;

public class Account {
	private String accountnumber;
	private String type;
	private List<String> transactiondata = new ArrayList<String>();
	
	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}
	
	public String getAccountnumber() {
		return accountnumber;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getType() {
		return type;
	}
	
	public void setTransactiondata(String transactiondata) {
		this.transactiondata.add(transactiondata);
	}
	
	public List<String> getTransactiondata() {
		return transactiondata;
	}
}
